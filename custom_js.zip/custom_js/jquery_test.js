(function($) {
	$(document).ready(function($) {	
		
		/*$(document).bind("contextmenu",function(e){
      return false;
   });*/
		
		if($('.lets-be p').text()){
			$(".wrapper .header, .wrapper .site-footer").remove();
			//$('.wrapper').children('header.header').remove('header');
		}
		
		var locName,otherOptions,interest,reason,staffCity,drName,branchVisit;
		var formLocationObject={
			locatedIn:'',
			interestedIn:[],
			reasonsToConsult:'',
			staffLocation:'',
			doctorsName:'',
			clinicCity:'',
			timeZone:'',
			preferTimeSlot:'',
			country:'',
			travelDetails:'',
			travelDate:''
		}
	
		 if($(".sub-menu>li").hasClass(".active")){
			//alert("test");
		}
		var liSelector =  $(".phy-leftmenu li.menu-item-has-children");
				liSelector.find('a').not('ul.sub-menu li.menu-item a').after("<span class='expand-icon'><img src='/../../wp-content/uploads/2023/04/Vector-2.png' alt='Expand Icon'></span>");
	
				/*var i = 0;
				$(liSelector).each(function(){				
						if(i == 0 && $(this).children("ul.sub-menu")){
							i = 1;
							//$(this).children("ul.sub-menu").show();
						} else if (i == 1 && $(this).children("ul.sub-menu")){
							//$(this).children("ul.sub-menu").hide();
						}
					});*/
				
				$(liSelector).each(function(){
						if( $(this).find("li.active").length > 0 ){
							$(this).not('ul.sub-menu li.menu-item').addClass("expanded");
							$(this).children("ul.sub-menu").show();
							$(this).find('a').css("color", "#721943");
							$(this).find('span.expand-icon').text('');
							$(this).find('span.expand-icon').append("<img src='/../../wp-content/uploads/2023/04/Vector-3.png' alt='Expand Icon'>");
						} else {
							$(this).children("ul.sub-menu").hide();
						}
					});		
				
				$(liSelector).click(function (e) {
					/*if($( this ).hasClass( 'expanded' )){
						$(this).find('ul.sub-menu').hide();
						$(this).removeClass("expanded");
						$(this).find('span.expand-icon').text('');
						$(this).find('span.expand-icon').append("<img src='/../../wp-content/uploads/2023/04/Vector-2.png' alt='Expand Icon'>");
						return false;
					}*/
					$(this).not('ul.sub-menu li.menu-item').addClass("expanded");
					$(this).find('span.expand-icon').text('');
					$(this).find('span.expand-icon').append("<img src='/../../wp-content/uploads/2023/04/Vector-3.png' alt='Expand Icon'>");
					$('.phy-leftmenu li > ul').hide();
					$(this).children("ul").toggle();
	
					$(liSelector).each(function(){
						if($(this).children("ul.sub-menu").css('display') == 'none'){				
							$(this).removeClass("expanded");
							$(this).find('span.expand-icon').text('');
							$(this).find('span.expand-icon').append("<img src='/../../wp-content/uploads/2023/04/Vector-2.png' alt='Expand Icon'>");
						}
					});
				});
		
				if(!!('ontouchstart' in window)){//check for touch device
					//behaviour and events for touch device
					
					// $(document).on('click touchstart', function(e){
					// 	if(e.type!="touchstart" || $(this).hasClass('dubaiMap') ){

					
						$(".dubaiMap")
						.bind("touchstart", function() {
							$('.dubaiClass.dubaiDiv').hide();
							$('.mob-dubai-Img').addClass('mobDivShow');
							$('.mob-dubai').addClass('mobHover');
							$('.dubaiClassContent.dubaiHoverContent').addClass('mobDivHide');
						})
						.bind("touchend", function() {
							setTimeout(function(){
								$('.mob-dubai').removeClass('mobHover');
								$('.mob-dubai-Img').removeClass('mobDivShow');
								$('.dubaiClassContent.dubaiHoverContent').removeClass('mobDivHide');
								$('.dubaiClass.dubaiDiv').show();
							},1000);
							
									
						})
					//}
					$('.abuDubaiMap').bind("touchstart", function() {

						$('.mob-dubai-Img').removeClass('mobDivShow');
						$('.dubaiClassContent.dubaiHoverContent').removeClass('mobDivHide');

							$('.abuDubaiDivv.dubaiDiv').hide();
							$('.mob-abudhabi').addClass('mobDivShow');
							$('.mob-dubai').addClass('mobHover');
							$('.abuDubaiCls.dubaiHoverContent').addClass('mobDivHide');	  
						}).bind("touchend", function() {
							setTimeout(function(){
							  $('.mob-dubai').removeClass('mobHover');
							  $('.mob-abudhabi').removeClass('mobDivShow');
							  $('.abuDubaiCls.dubaiHoverContent').removeClass('mobDivHide');
							  $('.abuDubaiDivv.dubaiDiv').show();
							},1000);
						})
					$('.ainDubaiMap').bind("touchstart", function() {
								$('.ainDubai.dubaiDiv').hide();
								$('.mob-ain').addClass('mobDivShow');
								$('.mob-dubai').addClass('mobHover');
								$('.ainDubaiContent.dubaiHoverContent').addClass('mobDivHide');
							}).bind("touchend", function() {
								setTimeout(function(){
								  $('.mob-dubai').removeClass('mobHover');
								  $('.mob-ain').removeClass('mobDivShow');
								  $('.ainDubaiContent.dubaiHoverContent').removeClass('mobDivHide');
								  $('.ainDubai.dubaiDiv').show();
								},1000);
							})
	
						 
					//})
				}
			
					else{
				
		  $('.dubaiMap').hover( 
		  function () {
				$('.dubaiClass.dubaiDiv').hide();
				$('.mob-dubai-Img').addClass('mobDivShow');
				$('.mob-dubai').addClass('mobHover');
				$('.dubaiClassContent.dubaiHoverContent').addClass('mobDivHide');
			
			  
			},function(){
				  $('.mob-dubai').removeClass('mobHover');
				  $('.mob-dubai-Img').removeClass('mobDivShow');
				  $('.dubaiClassContent.dubaiHoverContent').removeClass('mobDivHide');
				  $('.dubaiClass.dubaiDiv').show();
				
			})
	
		$('.ainDubaiMap').hover( 
		function () {
			$('.ainDubai.dubaiDiv').hide();
			$('.mob-ain').addClass('mobDivShow');
			$('.mob-dubai').addClass('mobHover');
			$('.ainDubaiContent.dubaiHoverContent').addClass('mobDivHide');
		
		  
		},function(){
			  $('.mob-dubai').removeClass('mobHover');
			  $('.mob-ain').removeClass('mobDivShow');
			  $('.ainDubaiContent.dubaiHoverContent').removeClass('mobDivHide');
			  $('.ainDubai.dubaiDiv').show();
			
		}
		)
	
		$('.abuDubaiMap').hover( 
		function () {
			$('.abuDubaiDivv.dubaiDiv').hide();
			$('.mob-abudhabi').addClass('mobDivShow');
			$('.mob-dubai').addClass('mobHover');
			$('.abuDubaiCls.dubaiHoverContent').addClass('mobDivHide');
		
		  
		},function(){
			  $('.mob-dubai').removeClass('mobHover');
			  $('.mob-abudhabi').removeClass('mobDivShow');
			  $('.abuDubaiCls.dubaiHoverContent').removeClass('mobDivHide');
			  $('.abuDubaiDivv.dubaiDiv').show();
			
		}
		)
	}
	
	$("#tabs").tabs();
	disbaleTabs();
	function disbaleTabs(){
		if($("#tabs>ul>li:not(.ui-tabs-active)")){
			$("#tabs>ul>li:not(.ui-tabs-active)").css({"pointer-events":"none"})
		}
	}
	
		$('.skip').click(function(){

		var active = $( "#tabs" ).tabs( "option", "active" );
		$( "#tabs" ).tabs( "option", "active", active + 1 );
		disbaleTabs();
		var active = $( "#tabs" ).tabs( "option", "active" );
		if(active == 2){
			formLocationObject.interestedIn="NA";
			formLocationObject.reasonsToConsult='NA';
		}
		if(active == 3){
				formLocationObject.staffLocation='NA',
				formLocationObject.doctorsName='NA',
				formLocationObject.clinicCity='NA',
				formLocationObject.timeZone='NA',
				formLocationObject.preferTimeSlot='NA',
				formLocationObject.country='NA',
				formLocationObject.travelDetails='NA',
				formLocationObject.travelDate='NA'

				myFormInfoSubmit();
		}
		if(formLocationObject.locatedIn == 'Abu Dhabi' || formLocationObject.locatedIn == 'Dubai' || formLocationObject.locatedIn == 'Al Ain'){
			$('.locationShow').show();
			$('.VirtualConsultation').hide();
			$('.InternationalPatients').hide();	
		}
		if(formLocationObject.locatedIn == 'Virtual consultation'){
			$('.VirtualConsultation').show();
			$('.InternationalPatients').hide();
			$('.locationShow').hide();
		}
		if(formLocationObject.locatedIn == 'International patients'){
			$('.InternationalPatients').show();
			$('.locationShow').hide();
			$('.VirtualConsultation').hide();
		}
		window.scrollTo(0, 0);
		})
		

	



		$('.previous').click(function(){
		
		var active = $( "#tabs" ).tabs( "option", "active" );
		$( "#tabs" ).tabs( "option", "active", active - 1 );
		disbaleTabs();
		window.scrollTo(0, 0);
		})
	
	if(formLocationObject.locatedIn == ''){
		$('.locationShow').show();
		$('.VirtualConsultation').hide();
		$('.InternationalPatients').hide();	
	}
	
	$('input[name="locName"]:radio').change(function () {
			$("#next").prop("disabled", false);
		});	
	const element = document.getElementById("next");
	element && element.addEventListener("click", myFunctionLocation);
	function myFunctionLocation() {
	formLocationObject;
	formLocationObject.locatedIn = $('input[name="locName"]:checked').val();
	 var active = $( "#tabs" ).tabs( "option", "active" );
	 $( "#tabs" ).tabs( "option", "active", active + 1);
	 disbaleTabs();
	 window.scrollTo(0, 0);
	}
	
	$('input[name="interest"]:radio' && 'input[name="reason"]:radio').change(function () {
			$("#consultationNext").prop("disabled", false);
		});	
	const elementTwo = document.getElementById("consultationNext");
	elementTwo && elementTwo.addEventListener("click", myFunctionConsultation);
	
	function myFunctionConsultation() {
	formLocationObject.interestedIn=[];
	let IVFValue=$('input[name="IVF"]:checked').val()||'';
	let FRValue=$('input[name="FR"]:checked').val()||'';
	let FBGTValue=$('input[name="FBGT"]:checked').val()||'';
	let FHValue=$('input[name="FH"]:checked').val()||'';
	if(IVFValue != ""){
		formLocationObject.interestedIn.push(IVFValue);
	}
	if(FRValue != ""){
		formLocationObject.interestedIn.push(FRValue);
	}
	if(FBGTValue != ""){
		formLocationObject.interestedIn.push(FBGTValue);
	}
	if(FHValue != ""){
		formLocationObject.interestedIn.push(FHValue);
	}
	formLocationObject.reasonsToConsult = $('input[name="reason"]:checked').val();
	 var active = $( "#tabs" ).tabs( "option", "active" );
	 $( "#tabs" ).tabs( "option", "active", active + 1 );
	 disbaleTabs();
	
		if(formLocationObject.locatedIn == 'Abu Dhabi' || formLocationObject.locatedIn == 'Dubai' || formLocationObject.locatedIn == 'Al Ain'){
			$('.locationShow').show();
			$('.VirtualConsultation').hide();
			$('.InternationalPatients').hide();	
		}
		if(formLocationObject.locatedIn == 'Virtual consultation'){
			$('.VirtualConsultation').show();
			$('.InternationalPatients').hide();
			$('.locationShow').hide();
		}
		if(formLocationObject.locatedIn == 'International patients'){
			$('.InternationalPatients').show();
			$('.locationShow').hide();
			$('.VirtualConsultation').hide();
		}


	  window.scrollTo(0, 0);
	}
	
	
	
	
	$('input[name="timeZone"]' && 'input[name="preferTimeSlot"]').keyup(function() {
		$("#consultWith").prop("disabled", false);
	});
	$('input[name="country"]' && 'input[name="travelDetails"]:radio' && 'input[name="travelDate"]').on("keyup change",function() {
		$("#consultWith").prop("disabled", false);
	});

	$(document).on("click", ".doctorAnchor" , function() {
		
		formLocationObject.doctorsName = $(this).children('.doctorName').val() || "NA";
		
	});
	$(document).on("click", ".sub-locations-tabs" , function() {
		
		formLocationObject.clinicCity = $(this).children('.doctorTimingsTablinks.active').text() || "NA";
		
	});
	
	/* Prasad */
	
	/*$('input[name="staffCity"]:radio').change(function () {
			$("#consultWith").prop("disabled", false);	
		});
		
	$(document).on("click", ".sub-locations-tabs .doctorTimingsTablinks" , function() {		
		$("#consultWith").prop("disabled", false);
	});*/
	
	$(document).on("click", ".doctorsData .doctors-list .doctorAnchor" , function() {		
		$("#consultWith").prop("disabled", false);
	});
	
	$(document).on("click", ".boxed2 .section-one span input" , function() {		
		var radioChecked = $(this).attr('checked');		
		if ( radioChecked === undefined || radioChecked === null ) {		
			$(this).attr('checked', true);
			$("#consultationNext").prop("disabled", false);
		}else{
			$(this).attr('checked', false);
		}		
	});
	
	/* Prasad End*/
	
	
	$("#selectCountry").click(function(){
	
		$.ajax({
			type: "GET",
			url: "https://restcountries.com/v3.1/independent?fields=name",
			cache: false,
			success: function(data){
				$.each(data, function (){
					$("#selectCountry").append($("<option/>").val(this.name['common']).text(this.name['common']));
				});
		
			}
			})
	})
	const elementThree = document.getElementById("consultWith");
	elementThree && elementThree.addEventListener("click", myFunctionConsultationWith);
	function myFunctionConsultationWith() {
	
	if(formLocationObject.locatedIn == 'Abu Dhabi' || formLocationObject.locatedIn == 'Dubai' || formLocationObject.locatedIn == 'Al Ain'){
		
	formLocationObject.staffLocation = $('input[name="staffCity"]:checked').val() || "NA";
	formLocationObject.timeZone="NA";
	formLocationObject.preferTimeSlot="NA";	
	formLocationObject.country="NA";
	formLocationObject.travelDetails="NA";
	formLocationObject.travelDate="NA";	
	}
	if(formLocationObject.locatedIn == 'Virtual consultation'){
	formLocationObject.timeZone=$('input[name="timeZone"]').val() || "NA";
	formLocationObject.preferTimeSlot=$('input[name="preferTimeSlot"]').val() || "NA";
	formLocationObject.country="NA";
	formLocationObject.travelDetails="NA";
	formLocationObject.travelDate="NA";	
	formLocationObject.staffLocation="NA";
	formLocationObject.doctorsName="NA";
	formLocationObject.clinicCity="NA";
	}
	if(formLocationObject.locatedIn == 'International patients'){
	formLocationObject.country = $('#selectCountry').val() || "NA";
	formLocationObject.travelDetails=$('input[name="travelDetails"]:checked').val() || "NA";
	formLocationObject.travelDate=$('input[name="travelDate"]').val() || "NA";	
	formLocationObject.staffLocation="NA";
	formLocationObject.doctorsName="NA";
	formLocationObject.clinicCity="NA";
	formLocationObject.timeZone="NA";
	formLocationObject.preferTimeSlot="NA";	
	}
	
	
	
		
	 var active = $( "#tabs" ).tabs( "option", "active" );
	 $( "#tabs" ).tabs( "option", "active", active + 1 );
	 disbaleTabs();
	 window.scrollTo(0, 0);
	  myFormInfoSubmit();
	}
	
	
	const elementFour = document.getElementById("personalInfo");
	elementFour && elementFour.addEventListener("click", myFormInfoSubmit);
	var locatedInData;
	function myFormInfoSubmit(){
		$("#location>div>input").val(formLocationObject.locatedIn);
		$("#interestedIn>div>input").val(formLocationObject.interestedIn);
		$("#reasonsToConsult>div>input").val(formLocationObject.reasonsToConsult);
		$("#staffLocation>div>input").val(formLocationObject.staffLocation);
		$("#doctorsName>div>input").val(formLocationObject.doctorsName);
		$("#clinicCity>div>input").val(formLocationObject.clinicCity);
		$("#timeZone>div>input").val(formLocationObject.timeZone);
		$("#preferTimeSlot>div>input").val(formLocationObject.preferTimeSlot);
		$("#country>div>input").val(formLocationObject.country);
		$("#travelDetails>div>input").val(formLocationObject.travelDetails);
		$("#travelDate>div>input").val(formLocationObject.travelDate);
		window.scrollTo(0, 0);
	}
		
	
	
		document.addEventListener( 'wpcf7mailsent', function( event ) {
			$("#tabs").hide();
			$(".responseThanku").show();
		}, false );
	
	});
	


	/* var radioChecked = $('.interestIn').is(':checked');

$('.interestIn').click(function() {
    radioChecked = !radioChecked;
    $(this).attr('checked', radioChecked);
}); */

	})(jQuery);